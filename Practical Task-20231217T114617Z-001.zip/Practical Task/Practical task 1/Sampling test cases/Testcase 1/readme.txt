L (Upsampling Factor) = 0
M (Downsampling Factor) = 2
The low pass filter specification can be found in filter specification file.