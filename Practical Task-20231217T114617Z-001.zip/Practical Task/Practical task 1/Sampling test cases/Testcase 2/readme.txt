L (Upsampling Factor) = 3
M (Downsampling Factor) = 0
The low pass filter specification can be found in filter specification file.