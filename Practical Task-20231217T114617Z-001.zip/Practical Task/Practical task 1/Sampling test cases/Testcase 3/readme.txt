L (Upsampling Factor) = 3
M (Downsampling Factor) = 2
The low pass filter specification can be found in filter specification file.